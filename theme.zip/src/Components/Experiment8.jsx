import { useEffect, useState } from "react";
import "./Experiment8.css";

function Experiment8() {
  const [seconds, setSeconds] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => clearInterval(timer);
  }, []);
  return (
    <section className="body-content exp8">
      <h2>8. Lifecycle Management using useEffect Hook</h2>
      <p><code>useEffect</code> runs side effects after rendering. This example starts and cleans up a timer.</p>
      <div className="info-card timer-card"><h3>Component has been mounted for</h3><div className="timer">{seconds}s</div><p>The interval is cleaned up when the component unmounts.</p></div>
    </section>
  );
}
export default Experiment8;
