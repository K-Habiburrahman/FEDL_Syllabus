import { useState } from "react";
import "./Experiment7.css";

function Experiment7() {
  const [items, setItems] = useState(["React", "JSX", "Props", "Hooks"]);
  const addItem = () => setItems([...items, `Item ${items.length + 1}`]);
  return (
    <section className="body-content exp7">
      <h2>7. Rendering Lists and Using Keys</h2>
      <p>React renders arrays with <code>map()</code>. Each item receives a stable <code>key</code>.</p>
      <div className="info-card list-card">
        <button className="demo-button" onClick={addItem}>Add Item</button>
        <ul>{items.map((item, index) => <li key={`${item}-${index}`}><span>{item}</span><small>key: {index}</small></li>)}</ul>
      </div>
    </section>
  );
}
export default Experiment7;
